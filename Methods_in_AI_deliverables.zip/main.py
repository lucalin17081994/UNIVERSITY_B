# -*- coding: utf-8 -*-


from dialogue_agent import Dialogue_Agent

da = Dialogue_Agent("dialog_acts.dat","restaurant_info.csv")
da.start_dialogue()
